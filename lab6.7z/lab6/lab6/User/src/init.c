
#include "init.h"

#define DAC_DHR12R1_ADDR  ((uint32_t)0x40007408) /* DAC ch1 12-bit right aligned */

void LEDs_Init_PD12(void)
{
    GPIO_InitTypeDef gpio;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

    gpio.GPIO_Pin   = GPIO_Pin_12;
    gpio.GPIO_Mode  = GPIO_Mode_OUT;
    gpio.GPIO_Speed = GPIO_Speed_2MHz;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_PuPd  = GPIO_PuPd_NOPULL;

    GPIO_Init(GPIOD, &gpio);
}

void GPIO_Init_PA4_DAC(void)
{
    GPIO_InitTypeDef gpio;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    gpio.GPIO_Pin  = GPIO_Pin_4;
    gpio.GPIO_Mode = GPIO_Mode_AN;
    gpio.GPIO_PuPd = GPIO_PuPd_NOPULL;

    GPIO_Init(GPIOA, &gpio);
}

void DAC1_Init_TriggeredByTIM2(void)
{
    DAC_InitTypeDef dac;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);

    DAC_StructInit(&dac);
    dac.DAC_Trigger = DAC_Trigger_T2_TRGO;
    dac.DAC_WaveGeneration = DAC_WaveGeneration_None;
    dac.DAC_OutputBuffer = DAC_OutputBuffer_Enable;

    DAC_Init(DAC_Channel_1, &dac);
    DAC_Cmd(DAC_Channel_1, ENABLE);

    DAC_DMACmd(DAC_Channel_1, ENABLE);
}

void DMA1_Stream5_Init_For_DAC1(uint16_t *buffer, uint32_t size)
{
    DMA_InitTypeDef dma;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);

    DMA_DeInit(DMA1_Stream5);
    while (DMA_GetCmdStatus(DMA1_Stream5) != DISABLE) { }

    DMA_StructInit(&dma);
    dma.DMA_Channel = DMA_Channel_7;

    dma.DMA_PeripheralBaseAddr = DAC_DHR12R1_ADDR;
    dma.DMA_Memory0BaseAddr    = (uint32_t)buffer;
    dma.DMA_DIR                = DMA_DIR_MemoryToPeripheral;
    dma.DMA_BufferSize         = size;

    dma.DMA_PeripheralInc      = DMA_PeripheralInc_Disable;
    dma.DMA_MemoryInc          = DMA_MemoryInc_Enable;

    dma.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    dma.DMA_MemoryDataSize     = DMA_MemoryDataSize_HalfWord;

    dma.DMA_Mode               = DMA_Mode_Circular;
    dma.DMA_Priority           = DMA_Priority_High;
    dma.DMA_FIFOMode           = DMA_FIFOMode_Disable;

    DMA_Init(DMA1_Stream5, &dma);
    DMA_Cmd(DMA1_Stream5, ENABLE);
}

void TIM2_Init_TRGO_Update(uint32_t update_hz)
{
    RCC_ClocksTypeDef clocks;
    uint32_t pclk1;
    uint32_t timclk;
    uint32_t target_base;
    uint32_t psc;
    uint32_t arr;
    TIM_TimeBaseInitTypeDef tim;

    RCC_GetClocksFreq(&clocks);

    pclk1  = clocks.PCLK1_Frequency;
    timclk = pclk1;

    /* if APB1 prescaler != 1 -> TIMCLK = 2*PCLK1 */
    if ((RCC->CFGR & RCC_CFGR_PPRE1) != RCC_CFGR_PPRE1_DIV1) {
        timclk = 2U * pclk1;
    }

    target_base = 10000U; /* 10 kHz base */

    psc = (timclk / target_base);
    if (psc == 0U) { psc = 1U; }
    psc = psc - 1U;

    arr = (target_base / update_hz);
    if (arr == 0U) { arr = 1U; }
    arr = arr - 1U;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    TIM_TimeBaseStructInit(&tim);
    tim.TIM_Prescaler     = (uint16_t)psc;
    tim.TIM_Period        = (uint32_t)arr;
    tim.TIM_CounterMode   = TIM_CounterMode_Up;
    tim.TIM_ClockDivision = TIM_CKD_DIV1;

    TIM_TimeBaseInit(TIM2, &tim);

    TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_Update);
    TIM_Cmd(TIM2, ENABLE);
}