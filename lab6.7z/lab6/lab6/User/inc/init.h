
#ifndef INIT_H
#define INIT_H

#include "stm32f4xx.h"
#include <stdint.h>

#define POINTS      40U
#define VREF        3.3f
#define DAC_MAX     4095.0f

#define V_MIN       0.5f     /* � */
#define V_MAX       2.0f     /* � */
#define PERIOD_MS   200U     /* �� */

/* Fs = POINTS / 0.2s = 200 Hz */
#define UPDATE_HZ   200U

extern uint16_t WaveTable[POINTS];

void LEDs_Init_PD12(void);
void GPIO_Init_PA4_DAC(void);
void TIM2_Init_TRGO_Update(uint32_t update_hz);
void DAC1_Init_TriggeredByTIM2(void);
void DMA1_Stream5_Init_For_DAC1(uint16_t *buffer, uint32_t size);

#endif